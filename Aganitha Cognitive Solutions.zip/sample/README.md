# Get Papers (Python 3.13 Edition)

A high-performance tool to fetch PubMed papers with pharmaceutical/biotech affiliations, optimized for Python 3.13.

## Features
- **Async Fetching**: Fast, non-blocking API calls with `httpx`.
- **Caching**: SQLite cache for repeat queries.
- **Batching**: Efficient processing of large PMID lists.
- **Progress Bar**: Real-time feedback with `tqdm`.
- **Default Output**: Saves to `pubmed_results.csv` if no filename is specified.
- **Python 3.13**: Leverages improved REPL, error messages, and docstring optimization.
- Built with Grok (xAI) assistance.

## Setup
1. Clone: `git clone https://github.com/yourusername/pubmed_fetcher.git`
2. Install: `poetry install`
3. Run: `poetry run get-papers-list "cancer vaccine" -f results.csv -d`

## Usage
- `get-papers-list <query> [-f file] [-d]`
- Example: `get-papers-list "heart disease" -f output.csv`
- Default: `get-papers-list "cancer vaccine"` saves to `pubmed_results.csv`
