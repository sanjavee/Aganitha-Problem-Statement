import httpx
import asyncio
import sqlite3
import csv
from xml.etree import ElementTree as ET
from tqdm import tqdm
import logging
from aiolimiter import AsyncLimiter

# API endpoints
SEARCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
FETCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"

# Rate limiter: 3 requests/second
rate_limiter = AsyncLimiter(3, 1)

def setup_cache():
    """Set up SQLite cache for fetched papers."""
    conn = sqlite3.connect("cache.db")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS papers (
            pmid TEXT PRIMARY KEY,
            title TEXT,
            pub_date TEXT,
            authors TEXT,
            companies TEXT,
            email TEXT
        )
    """)
    return conn

async def search_papers(query, client, max_results=100):
    """Search PubMed for PMIDs with async and rate limiting."""
    async with rate_limiter:
        params = {"db": "pubmed", "term": query, "retmax": max_results, "retmode": "json"}
        try:
            response = await client.get(SEARCH_URL, params=params)
            response.raise_for_status()
            pmids = response.json()["esearchresult"]["idlist"]
            logging.debug(f"Found {len(pmids)} PMIDs")
            return pmids
        except httpx.HTTPError as e:
            logging.error(f"Search failed: {e}")
            return []

async def fetch_batch(pmids, client, conn, batch_num):
    """Fetch a batch of PMIDs, using cache for speed."""
    results = []
    to_fetch = []

    cursor = conn.cursor()
    for pmid in pmids:
        cursor.execute("SELECT * FROM papers WHERE pmid = ?", (pmid,))
        cached = cursor.fetchone()
        if cached:
            results.append(dict(zip(
                ["PubmedID", "Title", "Publication Date", "Non-academic Author(s)",
                 "Company Affiliation(s)", "Corresponding Author Email"], cached)))
        else:
            to_fetch.append(pmid)

    if to_fetch:
        async with rate_limiter:
            params = {"db": "pubmed", "id": ",".join(to_fetch), "retmode": "xml"}
            try:
                response = await client.get(FETCH_URL, params=params)
                response.raise_for_status()
                root = ET.fromstring(response.content)
                for article in root.findall(".//PubmedArticle"):
                    result = parse_article(article)
                    if result:
                        results.append(result)
                        conn.execute(
                            "INSERT OR REPLACE INTO papers VALUES (?, ?, ?, ?, ?, ?)",
                            (result["PubmedID"], result["Title"], result["Publication Date"],
                             result["Non-academic Author(s)"], result["Company Affiliation(s)"],
                             result["Corresponding Author Email"])
                        )
                conn.commit()
                logging.debug(f"Processed batch {batch_num}: {len(to_fetch)} PMIDs")
            except httpx.HTTPError as e:
                logging.error(f"Fetch failed: {e}")

    return results

def parse_article(article):
    """Parse XML article and filter for company affiliations."""
    pmid = article.findtext(".//PMID") or "N/A"
    title = article.findtext(".//ArticleTitle") or "N/A"
    pub_date = article.findtext(".//PubDate/Year") or "N/A"

    authors = article.findall(".//Author")
    company_authors = []
    companies = []
    email = "N/A"

    for author in authors:
        name = f"{author.findtext('ForeName') or ''} {author.findtext('LastName') or ''}".strip()
        affiliation = author.findtext(".//Affiliation") or ""
        if is_company_affiliation(affiliation):
            company_authors.append(name)
            companies.append(affiliation.split(",")[0])
            email = author.findtext(".//AffiliationInfo/Email") or email

    if company_authors:
        return {
            "PubmedID": pmid,
            "Title": title,
            "Publication Date": pub_date,
            "Non-academic Author(s)": "; ".join(company_authors),
            "Company Affiliation(s)": "; ".join(companies),
            "Corresponding Author Email": email
        }
    return None

def is_company_affiliation(affiliation):
    """Check if affiliation suggests a company (not academic)."""
    affiliation = affiliation.lower()
    academic = ["university", "college", "lab"]
    companies = ["pharma", "biotech", "inc", "pfizer", "moderna"]
    return not any(a in affiliation for a in academic) and (
        any(c in affiliation for c in companies) or ("@" in affiliation and "." in affiliation)
    )

def save_to_csv(results, filename="pubmed_results.csv"):
    """Save results to CSV with a default filename if none provided."""
    headers = ["PubmedID", "Title", "Publication Date", "Non-academic Author(s)",
               "Company Affiliation(s)", "Corresponding Author Email"]
    if results:
        with open(filename, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            writer.writerows(results)
        print(f"Saved {len(results)} papers to {filename}")
    else:
        print("No papers found to save.")

async def run_fetch(query, filename, debug, batch_size=50):
    """Run the fetch process with clean output."""
    logging.basicConfig(
        level=logging.DEBUG if debug else logging.INFO,
        format="%(levelname)s: %(message)s"
    )
    if not debug:
        logging.getLogger("httpx").setLevel(logging.WARNING)

    conn = setup_cache()
    async with httpx.AsyncClient(timeout=30.0) as client:
        pmids = await search_papers(query, client)
        if not pmids:
            print("No papers found.")
            return

        results = []
        batches = range(0, len(pmids), batch_size)
        for i, batch_start in enumerate(tqdm(batches, desc="Fetching papers")):
            batch = pmids[batch_start:batch_start + batch_size]
            batch_results = await fetch_batch(batch, client, conn, i + 1)
            results.extend(batch_results)
        save_to_csv(results, filename if filename else "pubmed_results.csv")
    conn.close()
