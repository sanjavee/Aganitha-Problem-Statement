import argparse
import asyncio
from .fetcher import run_fetch

def main():
    """Parse CLI args and execute the fetcher."""
    parser = argparse.ArgumentParser(description="Fetch PubMed papers with company affiliations")
    parser.add_argument("query", help="PubMed search query (e.g., 'cancer vaccine')")
    parser.add_argument("-f", "--file", help="Output CSV file (default: pubmed_results.csv)")
    parser.add_argument("-d", "--debug", action="store_true", help="Show debug info")

    args = parser.parse_args()
    asyncio.run(run_fetch(args.query, args.file, args.debug))

if __name__ == "__main__":
    main()
